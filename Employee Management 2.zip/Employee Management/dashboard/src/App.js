import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AddEmployee from "./pages/AddEmployee";
import EditEmployee from "./pages/EditEmployee";
import Report from "./pages/Report";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="Home" element={<Home />} />
          <Route path="/" element={<Login />} />
          <Route path="Register" element={<Register />} />
          <Route path="AddEmployee" element={<AddEmployee />} />
          <Route path="EditEmployee" element={<EditEmployee />} />
          <Route path="Report" element={<Report />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
