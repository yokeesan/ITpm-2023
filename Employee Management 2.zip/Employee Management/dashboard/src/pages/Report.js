import React, { useState, useEffect } from "react";

import { PDFExport, savePDF } from "@progress/kendo-react-pdf";
import { useRef } from "react";
import { padding } from "@mui/system";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import axios from "axios";
import { Button } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { Container } from "@mui/material";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

export default function Report() {
  const [agent, setAgent] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  const getRequest = () => {
    axios.get("http://localhost:4000/Employee").then((response) => {
      setAgent(response.data);
    });
  };

  useEffect(() => {
    getRequest();
  }, [agent]);

  const PDFExportComponent = useRef(null);
  const pdfonclick = (e) => {
    PDFExportComponent.current.save();
  };

  return (
    <Paper sx={{ width: "100%", overflow: "hidden" }}>
      {/* <Button primary={true} onClick={pdfonclick}>Browse</Button> */}
      <Button
        variant="outlined"
        onClick={pdfonclick}
        style={{ padding: "5px 700px 5px 700px" }}
      >
        Export
      </Button>
      <PDFExport ref={PDFExportComponent}>
        <div></div>
        <Container>
          <TableContainer component={Paper} style={{ marginTop: "100px" }}>
            <Table sx={{ minWidth: 700 }} aria-label="customized table">
              <TableHead>
                <TableRow>
                  <StyledTableCell>FirstName</StyledTableCell>
                  <StyledTableCell align="right">LastName</StyledTableCell>
                  <StyledTableCell align="right">UserName</StyledTableCell>
                  <StyledTableCell align="right">Email</StyledTableCell>
                  <StyledTableCell align="right">Phone Number</StyledTableCell>
                  <StyledTableCell align="right">Address</StyledTableCell>
                  <StyledTableCell align="right">Position</StyledTableCell>
                  <StyledTableCell align="right">Salary</StyledTableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {agent
                  ? agent.map((row) => (
                      <StyledTableRow key={row._id}>
                        <StyledTableCell component="th" scope="row">
                          {row.FristName}
                        </StyledTableCell>
                        <StyledTableCell align="right">
                          {row.LastName}
                        </StyledTableCell>
                        <StyledTableCell align="right">
                          {row.UserName}
                        </StyledTableCell>
                        <StyledTableCell align="right">
                          {row.Email}
                        </StyledTableCell>
                        <StyledTableCell align="right">
                          {row.PhoneNumber}
                        </StyledTableCell>
                        <StyledTableCell align="right">
                          {row.Address}
                        </StyledTableCell>
                        <StyledTableCell align="right">
                          {row.Position}
                        </StyledTableCell>
                        <StyledTableCell align="right">
                          {row.Salary}
                        </StyledTableCell>
                      </StyledTableRow>
                    ))
                  : null}
              </TableBody>
            </Table>
          </TableContainer>
        </Container>
      </PDFExport>
    </Paper>
  );
}
