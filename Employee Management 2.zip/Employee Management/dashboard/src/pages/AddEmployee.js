import React from "react";
import NavBar from "./NavBar";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function AddEmployee() {
  const bull = (
    <Box
      component="span"
      sx={{ display: "inline-block", mx: "2px", transform: "scale(0.8)" }}
    >
      •
    </Box>
  );

  const [FristName, setFristName] = React.useState("");
  const [LastName, setLastName] = React.useState("");
  const [UserName, setUserName] = React.useState("");
  const [Email, setEmail] = React.useState("");
  const [PhoneNumber, setPhoneNumber] = React.useState("");
  const [Address, setAddress] = React.useState("");
  const [Position, setPosition] = React.useState("");
  const [Salary, setSalary] = React.useState("");

  const navigate = useNavigate();

  const handleSubmit = () => {
    const bodt = {
      FristName: FristName,
      LastName: LastName,
      UserName: UserName,
      Email: Email,
      PhoneNumber: PhoneNumber,
      Address: Address,
      Position: Position,
      Salary: Salary,
    };

    console.log("bodt :", bodt);

    if (
      FristName == "" ||
      LastName == "" ||
      UserName == "" ||
      Email == "" ||
      PhoneNumber == "" ||
      Address == "" ||
      Position == "" ||
      Salary == ""
    ) {
      alert("Please fill all required fields...");
    } else {
      axios
        .post("http://localhost:4000/Employee", bodt)
        .then((res) => {
          console.log(res.data);
          navigate("/Home");
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };

  return (
    <>
      <NavBar />
      <center>
        <Card
          sx={{
            minWidth: 275,
            maxWidth: "50%",
            marginTop: "50px",
            marginBottom: "50px",
          }}
        >
          <CardContent>
            <Typography
              sx={{ fontSize: 14 }}
              color="text.secondary"
              gutterBottom
            >
              <h1>Add New Employee</h1>
            </Typography>
            <div>
              <TextField
                id="standard-basic"
                label="FirstName"
                variant="standard"
                style={{ width: "50%" }}
                value={FristName}
                onChange={(e) => setFristName(e.target.value)}
              />
              <br />
              <TextField
                id="standard-basic"
                label="LastName"
                variant="standard"
                style={{ width: "50%", marginTop: "30px" }}
                value={LastName}
                onChange={(e) => setLastName(e.target.value)}
              />
              <br />
              <TextField
                id="standard-basic"
                label="UserName"
                variant="standard"
                style={{ width: "50%", marginTop: "30px" }}
                value={UserName}
                onChange={(e) => setUserName(e.target.value)}
              />
              <br />
              <TextField
                id="standard-basic"
                label="Email"
                variant="standard"
                style={{ width: "50%", marginTop: "30px" }}
                value={Email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <br />
              <TextField
                id="standard-basic"
                label="PhoneNumber"
                variant="standard"
                style={{ width: "50%", marginTop: "30px" }}
                value={PhoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
              />
              <br />
              <TextField
                id="standard-basic"
                label="Address"
                variant="standard"
                style={{ width: "50%", marginTop: "30px" }}
                value={Address}
                onChange={(e) => setAddress(e.target.value)}
              />
              <br />
              <TextField
                id="standard-basic"
                label="Position"
                variant="standard"
                style={{ width: "50%", marginTop: "30px" }}
                value={Position}
                onChange={(e) => setPosition(e.target.value)}
              />
              <br />
              <TextField
                id="standard-basic"
                label="Salary"
                variant="standard"
                style={{ width: "50%", marginTop: "30px" }}
                value={Salary}
                onChange={(e) => setSalary(e.target.value)}
              />
              <br />
              <Button
                variant="outlined"
                style={{ width: "50%", marginTop: "50px" }}
                onClick={() => handleSubmit()}
              >
                Submit
              </Button>
            </div>
          </CardContent>
        </Card>
      </center>
    </>
  );
}

export default AddEmployee;
