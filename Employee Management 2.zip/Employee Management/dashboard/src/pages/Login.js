import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import { useNavigate } from "react-router-dom";

function Login() {
  const bull = (
    <Box
      component="span"
      sx={{ display: "inline-block", mx: "2px", transform: "scale(0.8)" }}
    >
      •
    </Box>
  );

  const [username, setUserName] = React.useState("");
  const [password, setPassword] = React.useState("");

  const navigate = useNavigate();

  const handleSubmit = () => {
    console.log(username);
    console.log(password);

    if (username === "" || password === "") {
      alert("Please fill all required fields");
    } else if (username === "admin" || password === "password") {
      alert("Login Success...!");
      navigate("/Home");
    } else {
      alert("Login failure...!");
    }
  };

  return (
    <div>
      {" "}
      <center>
        <Card sx={{ minWidth: 275, maxWidth: "50%", marginTop: "200px" }}>
          <CardContent>
            <Typography
              sx={{ fontSize: 14 }}
              color="text.secondary"
              gutterBottom
            >
              <h1>Login Now</h1>
            </Typography>
            <div>
              <TextField
                id="standard-basic"
                label="UserName"
                variant="standard"
                style={{ width: "50%" }}
                value={username}
                onChange={(e) => setUserName(e.target.value)}
              />
              <br />
              <TextField
                id="standard-basic"
                label="Password"
                variant="standard"
                type="password"
                style={{ width: "50%", marginTop: "30px" }}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <br />
              <Button
                variant="outlined"
                style={{ width: "50%", marginTop: "50px" }}
                onClick={() => handleSubmit()}
              >
                Login
              </Button>
            </div>
          </CardContent>
        </Card>
      </center>
    </div>
  );
}

export default Login;
