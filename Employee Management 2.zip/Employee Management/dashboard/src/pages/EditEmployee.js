import React, { useEffect } from "react";
import NavBar from "./NavBar";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function EditEmployee() {
  const bull = (
    <Box
      component="span"
      sx={{ display: "inline-block", mx: "2px", transform: "scale(0.8)" }}
    >
      •
    </Box>
  );

  const EmpID = window.sessionStorage.getItem("ID");

  const [FristName, setFristName] = React.useState("");
  const [LastName, setLastName] = React.useState("");
  const [UserName, setUserName] = React.useState("");
  const [Email, setEmail] = React.useState("");
  const [PhoneNumber, setPhoneNumber] = React.useState("");
  const [Address, setAddress] = React.useState("");
  const [Position, setPosition] = React.useState("");
  const [Salary, setSalary] = React.useState("");

  const [getEmployee, setgetEmployee] = React.useState([]);
  useEffect(() => {
    axios
      .get(`http://localhost:4000/Employee/${EmpID}`)
      .then((res) => {
        console.log(res.data);
        setgetEmployee(res.data);
        setFristName(res.FristName);
        setLastName(res.LastName);
        setUserName(res.UserName);
        setEmail(res.Email);
        setPhoneNumber(res.PhoneNumber);
        setAddress(res.Address);
        setPosition(res.Position);
        setSalary(res.Salary);
      })
      .catch((err) => {
        console.log(err);
      });
  }, [EmpID]);

  const navigate = useNavigate();

  const handleSubmit = () => {
    const bodt = {
      FristName: FristName ? FristName : getEmployee.FristName,
      LastName: LastName ? LastName : getEmployee.LastName,
      UserName: UserName ? UserName : getEmployee.UserName,
      Email: Email ? Email : getEmployee.Email,
      PhoneNumber: PhoneNumber ? PhoneNumber : getEmployee.PhoneNumber,
      Address: Address ? Address : getEmployee.Address,
      Position: Position ? Position : getEmployee.Position,
      Salary: Salary ? Salary : getEmployee.Salary,
    };

    axios
      .patch(`http://localhost:4000/Employee/${EmpID}`, bodt)
      .then((res) => {
        console.log(res.data);
        navigate("/Home");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <>
      <NavBar />
      <center>
        <Card
          sx={{
            minWidth: 275,
            maxWidth: "50%",
            marginTop: "50px",
            marginBottom: "50px",
          }}
        >
          <CardContent>
            <Typography
              sx={{ fontSize: 14 }}
              color="text.secondary"
              gutterBottom
            >
              <h1>Add New Employee</h1>
            </Typography>
            <div>
              <label style={{ marginTop: "10px" }}>First Name</label>
              <br />
              <input
                style={{
                  padding: 10,
                  width: "50%",
                  marginTop: "5px",
                  fontSize: 15,
                }}
                type="text"
                defaultValue={getEmployee.FristName}
                onChange={(e) => setFristName(e.target.value)}
              />
              <br />
              <label style={{ marginTop: "10px" }}>Last Name</label>
              <br />
              <input
                style={{
                  padding: 10,
                  width: "50%",
                  marginTop: "5px",
                  fontSize: 15,
                }}
                type="text"
                defaultValue={getEmployee.LastName}
                onChange={(e) => setLastName(e.target.value)}
              />
              <br />
              <label style={{ marginTop: "10px" }}>User Name</label>
              <br />
              <input
                style={{
                  padding: 10,
                  width: "50%",
                  marginTop: "5px",
                  fontSize: 15,
                }}
                type="text"
                defaultValue={getEmployee.UserName}
                onChange={(e) => setUserName(e.target.value)}
              />
              <br />
              <label style={{ marginTop: "10px" }}>Email</label>
              <br />
              <input
                style={{
                  padding: 10,
                  width: "50%",
                  marginTop: "5px",
                  fontSize: 15,
                }}
                type="text"
                defaultValue={getEmployee.Email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <br />
              <label style={{ marginTop: "10px" }}>Phone Number</label>
              <br />
              <input
                style={{
                  padding: 10,
                  width: "50%",
                  marginTop: "5px",
                  fontSize: 15,
                }}
                type="text"
                defaultValue={getEmployee.PhoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
              />
              <br />
              <label style={{ marginTop: "10px" }}>Address</label>
              <br />
              <input
                style={{
                  padding: 10,
                  width: "50%",
                  marginTop: "5px",
                  fontSize: 15,
                }}
                type="text"
                defaultValue={getEmployee.Address}
                onChange={(e) => setAddress(e.target.value)}
              />
              <br />
              <label style={{ marginTop: "10px" }}>Position</label>
              <br />
              <input
                style={{
                  padding: 10,
                  width: "50%",
                  marginTop: "5px",
                  fontSize: 15,
                }}
                type="text"
                defaultValue={getEmployee.Position}
                onChange={(e) => setPosition(e.target.value)}
              />
              <br />
              <label style={{ marginTop: "10px" }}>Salary</label>
              <br />
              <input
                style={{
                  padding: 10,
                  width: "50%",
                  marginTop: "5px",
                  fontSize: 15,
                }}
                type="text"
                defaultValue={getEmployee.Salary}
                onChange={(e) => setSalary(e.target.value)}
              />
              <br />
              <Button
                variant="outlined"
                style={{ width: "50%", marginTop: "50px" }}
                onClick={() => handleSubmit()}
              >
                Submit
              </Button>
            </div>
          </CardContent>
        </Card>
      </center>
    </>
  );
}

export default EditEmployee;
