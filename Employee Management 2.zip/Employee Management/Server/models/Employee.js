const mongoose = require("mongoose");

const EmployeeSchema = mongoose.Schema({
  FristName: {
    type: String,
    require: true,
  },
  LastName: {
    type: String,
    require: true,
  },
  UserName: {
    type: String,
    require: true,
  },
  Email: {
    type: String,
    require: true,
  },
  PhoneNumber: {
    type: String,
    require: true,
  },
  Address: {
    type: String,
    require: true,
  },
  Position: {
    type: String,
    require: true,
  },
  Salary: {
    type: String,
    require: true,
  },
});

module.exports = mongoose.model("Employee", EmployeeSchema);
