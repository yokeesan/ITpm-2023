const express = require("express");
const router = express.Router();
const Employee = require("../models/Employee");

//GET ALL THE CLEANING COMPANY DETAILS
router.get("/", async (req, res) => {
  try {
    const employee = await Employee.find();
    res.json(employee);
  } catch (err) {
    res.json({ message: err });
  }
});

//SUBMIT CLEANING COMPANY INFORMATION
router.post("/", async (req, res) => {
  const employee = new Employee({
    FristName: req.body.FristName,
    LastName: req.body.LastName,
    UserName: req.body.UserName,
    Email: req.body.Email,
    PhoneNumber: req.body.PhoneNumber,
    Address: req.body.Address,
    Position: req.body.Position,
    Salary: req.body.Salary,
  });

  try {
    const savedemployee = await employee.save();
    res.json(savedemployee);
  } catch (err) {
    res.json({ message: err });
  }
});

//SPECIFIC CLEANING COMPANY
router.get("/:employeeID", async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.employeeID);
    res.json(employee);
  } catch (err) {
    res.json({ message: err });
  }
});

//DELETE SPECIFIC CLEANING COMPANY
router.delete("/:employeeID", async (req, res) => {
  try {
    const removeEmployee = await Employee.remove({
      _id: req.params.employeeID,
    });
    res.json(removeEmployee);
  } catch (err) {
    res.json({ message: err });
  }
});

//UPDATE A CLEANING COMPANY DETAILS
router.patch("/:employeeID", async (req, res) => {
  try {
    const updateEmployee = await Employee.updateOne(
      { _id: req.params.employeeID },
      {
        $set: {
          FristName: req.body.FristName,
          LastName: req.body.LastName,
          UserName: req.body.UserName,
          Email: req.body.Email,
          PhoneNumber: req.body.PhoneNumber,
          Address: req.body.Address,
          Position: req.body.Position,
          Salary: req.body.Salary,
        },
      }
    );
    res.json(updateEmployee);
  } catch (err) {
    res.json({ message: err });
  }
});

module.exports = router;
