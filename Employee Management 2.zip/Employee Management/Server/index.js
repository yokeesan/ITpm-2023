require("dotenv/config");
const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

const cors = require("cors");
const app = express();
app.use(cors());

app.use(bodyParser.json());

//Import Routers
const employeeRoute = require("./routes/employee");

app.use("/Employee", employeeRoute);

app.get("/", (req, res) => {
  res.send("Server is running on localhost 3000");
});

const CONNECTION_URL =
  "mongodb+srv://Kune:Kune@cluster0.ozbws.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
const PORT = process.env.PORT || 4000;

//Connect to DB
mongoose
  .connect(CONNECTION_URL, {
    useNewUrlParser: true,
  })
  .then(() =>
    app.listen(PORT, () => console.log(`Server running on port : ${PORT}`))
  )
  .catch((error) => console.log(error.message));

//http://localhost:3000/
